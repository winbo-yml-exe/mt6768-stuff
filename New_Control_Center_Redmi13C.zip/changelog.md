# Version OneDotZero
Note: This module is free of charge, 
and will remain this way for the support lifetime of the project,
any distributed file may be linked to this channel,
but also shared and modified at will;
as long as the original project name gets stripped and 
new contributors added to the credits.

# Initial features
## Kernel related setup:
* Code cleanup from Snapdragon 680 base.
* Proper scheduler setup for Snapdragon 685.
* Raised minimum frequency of Little cluster due to downgraded performance over diminished power drop.
* Background process limited to 2 efficiency cores.

## System:
* Enabled Smart FPS.
* Enabled blur originally limited to > 8GB devices.
